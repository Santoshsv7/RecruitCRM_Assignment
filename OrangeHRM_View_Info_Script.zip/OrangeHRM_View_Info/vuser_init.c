vuser_init()
{
	
	web_cache_cleanup();
	
	web_cleanup_cookies();
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_max_html_param_len("999999");
	
	web_set_sockets_option("TLS_SNI", "0");
	
		web_reg_save_param_regexp(
		"ParamName=_token",
		"RegExp=quot;(.*?)&quot",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/login*",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=v",
		"RegExp=href=\"/web/dist/favicon\\.ico\\?v=(.*?)\">\\\n\\ \\ \\ \\ ",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/login*",
		LAST);

  web_reg_find ("Text=orangehrm","SaveCount=LaunchCount",LAST);
  
     
    lr_start_transaction("HRM_View_MyInfo_01_Launch");

	web_url("opensource-demo.orangehrmlive.com", 
		"URL={p_URL}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTTP", 
		LAST);
    
	
    if(atoi(lr_eval_string("LaunchCount"))<0)

    {
     lr_end_transaction("HRM_View_MyInfo_01_Launch",LR_FAIL); 
     lr_error_message("Launch Failed");
    }
    else
    {
    lr_end_transaction("HRM_View_MyInfo_01_Launch",LR_PASS);
    lr_output_message("Launched Successfully");
    
    }
    
   
    
	web_reg_find ("Text=Redirecting","SaveCount=LoginCount",LAST);
	
	lr_start_transaction("HRM_View_MyInfo_02_Login");

	web_submit_data("validate",
		"Action={p_URL}/web/index.php/auth/validate",
		"Method=POST",
		"RecContentType=text/html",
		"Referer={p_URL}/web/index.php/auth/login",
		"Snapshot=t44.inf",
		"Mode=HTTP",
		ITEMDATA,
		"Name=_token", "Value={_token}", ENDITEM,
		"Name=username", "Value=Admin", ENDITEM,
		"Name=password", "Value=admin123", ENDITEM,
		LAST);

   web_url("messages_2", 
		"URL={p_URL}/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t45.inf", 
		"Mode=HTTP", 
		LAST); 

	web_url("7", 
		"URL={p_URL}/web/index.php/pim/viewPhoto/empNumber/7", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t49.inf", 
		LAST);

	web_url("time-at-work", 
		"URL={p_URL}/web/index.php/api/v2/dashboard/employees/time-at-work?timezoneOffset=5.5&currentDate={p_Current_Date}&currentTime={p_Current_time}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t50.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("action-summary", 
		"URL={p_URL}/web/index.php/api/v2/dashboard/employees/action-summary", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t51.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("shortcuts", 
		"URL={p_URL}/web/index.php/api/v2/dashboard/shortcuts", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t55.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("feed", 
		"URL={p_URL}/web/index.php/api/v2/buzz/feed?limit=5&offset=0&sortOrder=DESC&sortField=share.createdAtUtc", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t56.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("leaves", 
		"URL={p_URL}/web/index.php/api/v2/dashboard/employees/leaves?date={p_Current_Date}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t57.inf", 
		"Mode=HTTP", 
		LAST);

	web_custom_request("push", 
		"URL={p_URL}/web/index.php/events/push", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t58.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("subunit", 
		"URL={p_URL}/web/index.php/api/v2/dashboard/employees/subunit", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t59.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("locations", 
		"URL={p_URL}/web/index.php/api/v2/dashboard/employees/locations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t60.inf", 
		"Mode=HTTP", 
		LAST);
	
	  if(atoi(lr_eval_string("LoginCount"))<0)
    {
     lr_end_transaction("HRM_View_MyInfo_02_Login",LR_FAIL);  
     lr_error_message("Login Failed");     
    }
    else
    {
    lr_end_transaction("HRM_View_MyInfo_02_Login",LR_PASS);
    lr_output_message("LoggedIn Successfully");
    }
	
	return 0;
}
