Action()
{

	
    web_reg_find ("Text=PersonalDetails","SaveCount=MyInfo_Count",LAST);

	lr_start_transaction("HRM_View_MyInfo_03_MyInfo");

	web_url("viewMyDetails", 
		"URL={p_URL}/web/index.php/pim/viewMyDetails", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t61.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("messages_3", 
		"URL={p_URL}/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t62.inf", 
		"Mode=HTTP", 
		LAST);


	web_url("7_2", 
		"URL={p_URL}/web/index.php/pim/viewPhoto/empNumber/7", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t63.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7_3", 
		"URL={p_URL}/web/index.php/api/v2/pim/employees/7", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t64.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("attachments", 
		"URL={p_URL}/web/index.php/api/v2/pim/employees/7/screen/personal/attachments?limit=50&offset=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t65.inf", 
		"Mode=HTTP", 
		LAST);

/*	web_url("workweek", 
		"URL={p_URL}/web/index.php/api/v2/leave/workweek?model=indexed", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t66.inf", 
		"Mode=HTTP", 
		LAST);  */

	web_url("personal-details", 
		"URL={p_URL}/web/index.php/api/v2/pim/employees/7/personal-details", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t67.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("custom-fields", 
		"URL={p_URL}/web/index.php/api/v2/pim/employees/7/custom-fields?screen=personal", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t68.inf", 
		"Mode=HTTP", 
		LAST);

/*	web_url("holidays", 
		"URL={p_URL}/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t69.inf", 
		"Mode=HTTP", 
		LAST);  */

/*	web_url("workweek_2", 
		"URL={p_URL}/web/index.php/api/v2/leave/workweek?model=indexed", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t70.inf", 
		"Mode=HTTP", 
		LAST); */

	web_url("employees", 
		"URL={p_URL}/web/index.php/api/v2/pim/employees", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t71.inf", 
		"Mode=HTTP", 
		LAST);

/*	web_url("holidays_2", 
		"URL={p_URL}/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t72.inf", 
		"Mode=HTTP", 
		LAST); */
	
	
	 if(atoi(lr_eval_string("MyInfo_Count"))<0)
    {
     lr_end_transaction("HRM_View_MyInfo_03_MyInfo",LR_FAIL);   
     lr_error_message("MyInfo Page  Failed");     
    }
    else
    {
    lr_end_transaction("HRM_View_MyInfo_03_MyInfo",LR_PASS);
    lr_output_message("MyInfo page opened Successfully");
    }


	return 0;
}