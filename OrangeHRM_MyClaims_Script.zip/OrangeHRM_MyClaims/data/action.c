Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"125\", \"Chromium\";v=\"125\", \"Not.A/Brand\";v=\"24\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("opensource-demo.orangehrmlive.com", 
		"URL=https://opensource-demo.orangehrmlive.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/web/images/ohrm_logo.png", "Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", ENDITEM, 
		"Url=/web/images/ohrm_branding.png?v=1711595107870", "Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("contentType", 
		"application/json");

	web_url("messages", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/web/dist/img/blob.svg", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/app.css?v=1711595107870", ENDITEM, 
		"Url=/web/dist/fonts/bootstrap-icons.woff2", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", ENDITEM, 
		"Url=/web/dist/fonts/nunito-sans-v6-latin-ext_latin-800.woff2", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", ENDITEM, 
		"Url=/web/dist/fonts/nunito-sans-v6-latin-ext_latin-regular.woff2", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", ENDITEM, 
		"Url=/web/dist/fonts/nunito-sans-v6-latin-ext_latin-600.woff2", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_data("validate", 
		"Action=https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=f7364a955af6f5.bdkoWKuqiVinIGo-jUABCiszA0O9X6dL14BGoV8OZ8w.Fb9RHv_DzCjFFjVqyzp4YQYHZymJN4oA4rAVkBNEDLYd734Mxu76bvRYJw", ENDITEM, 
		"Name=username", "Value=Admin", ENDITEM, 
		"Name=password", "Value=admin123", ENDITEM, 
		EXTRARES, 
		"Url=/web/images/orange.png?v=1711595107870", "Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", ENDITEM, 
		"Url=/web/images/orangehrm-logo.png?v=1711595107870", "Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", ENDITEM, 
		"Url=/web/images/dashboard_empty_widget_watermark.png", "Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", ENDITEM, 
		"Url=../pim/viewPhoto/empNumber/7", "Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_url("action-summary", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/action-summary", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("time-at-work", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/time-at-work?timezoneOffset=5.5&currentDate=2024-05-28&currentTime=23:31", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_url("feed", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/buzz/feed?limit=5&offset=0&sortOrder=DESC&sortField=share.createdAtUtc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("leaves", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/leaves?date=2024-05-28", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("locations", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/locations", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_custom_request("push", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/events/push", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("shortcuts", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/shortcuts", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_url("subunit", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/subunit", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/web/dist/fonts/nunito-sans-v6-latin-ext_latin-700.woff2", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", ENDITEM, 
		"Url=/web/dist/fonts/nunito-sans-v6-latin-ext_latin-300.woff2", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", ENDITEM, 
		"Url=/web/dist/fonts/nunito-sans-v6-latin-ext_latin-italic.woff2", "Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", ENDITEM, 
		LAST);

	lr_start_transaction("Click_Claim");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("viewClaimModule", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaimModule", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("7", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPhoto/empNumber/7", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("requests", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/claim/employees/requests?limit=50&offset=0&includeEmployees=onlyCurrent&sortField=claimRequest.referenceId&sortOrder=DESC", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("events", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/claim/events?limit=0&status=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("holidays", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_url("holidays_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	lr_end_transaction("Click_Claim",LR_AUTO);

	lr_start_transaction("myClaims");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("viewClaim", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("7_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPhoto/empNumber/7", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("requests_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/claim/requests?limit=50&offset=0&sortField=claimRequest.referenceId&sortOrder=DESC", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_url("events_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/claim/events?limit=0&status=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("holidays_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);

	web_url("workweek_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		LAST);

	web_url("holidays_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	lr_end_transaction("myClaims",LR_AUTO);

	lr_start_transaction("view_Details");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(24);

	web_url("3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/claim/submitClaim/id/3", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/viewClaim", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_5", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("7_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPhoto/empNumber/7", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("3_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/claim/requests/3", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	web_url("expenses", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/claim/requests/3/expenses?limit=50&offset=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		LAST);

	web_url("attachments", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/claim/requests/3/attachments?limit=50&offset=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_end_transaction("view_Details",LR_AUTO);

	lr_start_transaction("logout");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("logout", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/auth/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_6", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("logout",LR_AUTO);

	return 0;
}