Action()
{
     web_reg_find ("Text=AssignClaim","SaveCount=ClaimCount",LAST);

    lr_start_transaction("HRM_MyClaims_03_Click_Claim");

	web_url("viewClaimModule", 
		"URL={p_URL}/web/index.php/claim/viewClaimModule", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_url("messages_3", 
		"URL={p_URL}/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	web_url("7", 
		"URL={p_URL}/web/index.php/pim/viewPhoto/empNumber/7", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_url("requests", 
		"URL={p_URL}/web/index.php/api/v2/claim/employees/requests?limit=50&offset=0&includeEmployees=onlyCurrent&sortField=claimRequest.referenceId&sortOrder=DESC", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("events", 
		"URL={p_URL}/web/index.php/api/v2/claim/events?limit=0&status=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	if(atoi(lr_eval_string("ClaimCount"))<0)

    {
     lr_end_transaction("HRM_MyClaims_03_Click_Claim",LR_FAIL); 
     lr_error_message("Click_Claim Page Failed");     
    }
    else
    {
    lr_end_transaction("HRM_MyClaims_03_Click_Claim",LR_PASS);
    lr_output_message("Click_Claim Page opened Successfully");
    }

    
    web_reg_find ("Text=OrangeHRM","SaveCount=myClaimsCount",LAST);
    
	
    lr_start_transaction("HRM_MyClaims_04_myClaims");

	web_url("viewClaim", 
		"URL={p_URL}/web/index.php/claim/viewClaim", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={p_URL}/web/index.php/claim/viewAssignClaim", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	web_url("messages_4", 
		"URL={p_URL}/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_url("7_2", 
		"URL={p_URL}/web/index.php/pim/viewPhoto/empNumber/7", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_url("requests_2", 
		"URL={p_URL}/web/index.php/api/v2/claim/requests?limit=50&offset=0&sortField=claimRequest.referenceId&sortOrder=DESC", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_url("events_2", 
		"URL={p_URL}/web/index.php/api/v2/claim/events?limit=0&status=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

/*	web_url("workweek_3", 
		"URL={p_URL}/web/index.php/api/v2/leave/workweek?model=indexed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);  */


/*	web_url("holidays_3", 
		"URL={p_URL}/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST); */

/*	web_url("workweek_4", 
		"URL={p_URL}/web/index.php/api/v2/leave/workweek?model=indexed", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		LAST);  */

/*	web_url("holidays_4", 
		"URL={p_URL}/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST); */
	
	if(atoi(lr_eval_string("myClaimsCount"))<0)

    {
     lr_end_transaction("HRM_MyClaims_04_myClaims",LR_FAIL);
     lr_error_message("MyClaims Page Failed");     
    }
    else
    {
    lr_end_transaction("HRM_MyClaims_04_myClaims",LR_PASS);
    lr_output_message("MyClaims Page opened Successfully");
    }
    
    
    web_reg_find ("Text=OrangeHRM","SaveCount=view_Details_Count",LAST);
    
	lr_start_transaction("HRM_MyClaims_05_view_Details");

	web_url("3", 
		"URL={p_URL}/web/index.php/claim/submitClaim/id/3", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={p_URL}/web/index.php/claim/viewClaim", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	web_url("messages_5", 
		"URL={p_URL}/web/index.php/core/i18n/messages", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		LAST);

	web_url("7_3", 
		"URL={p_URL}/web/index.php/pim/viewPhoto/empNumber/7", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		LAST);

	web_url("3_2", 
		"URL={p_URL}/web/index.php/api/v2/claim/requests/3", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		LAST);

	web_url("expenses", 
		"URL={p_URL}/web/index.php/api/v2/claim/requests/3/expenses?limit=50&offset=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		LAST);

	web_url("attachments", 
		"URL={p_URL}/web/index.php/api/v2/claim/requests/3/attachments?limit=50&offset=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/claim/submitClaim/id/3", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	
	if(atoi(lr_eval_string("view_Details_Count"))<0)

    {
     lr_end_transaction("HRM_MyClaims_05_view_Details",LR_FAIL);  
     lr_error_message("View_Details Page Failed");     
    }
    else
    {
    lr_end_transaction("HRM_MyClaims_05_view_Details",LR_PASS);
    lr_output_message("View_Details Page opened Successfully");
    }


	return 0;
}