vuser_end()
{   
	 web_reg_find("Text=login","SaveCount=logout_Count",LAST);
    
	lr_start_transaction("HRM_MyClaims_06_Logout");

	web_url("logout", 
		"URL={p_URL}/web/index.php/auth/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={p_URL}/web/index.php/pim/viewPersonalDetails/empNumber/7", 
		"Snapshot=t73.inf", 
		"Mode=HTTP", 
		LAST);


	web_url("messages_4", 
		"URL={p_URL}/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/auth/login", 
		"Snapshot=t74.inf", 
		"Mode=HTTP", 
		LAST);
	
	
	if(atoi(lr_eval_string("logout_Count"))<0)
    {
     lr_end_transaction("HRM_MyClaims_06_Logout",LR_FAIL); 
     lr_error_message("Logout Failed");     
    }
    else
    {
    lr_end_transaction("HRM_MyClaims_06_Logout",LR_PASS);
    lr_output_message("LoggedOut Successfully");
    }
	
    return 0;
}
