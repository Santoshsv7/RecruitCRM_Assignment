Action()
{
    web_reg_find ("Text=EmployeeTimesheet","SaveCount=TimeCount",LAST);
	
	lr_start_transaction("HRM_Time_03_Click_Time");

	web_url("viewTimeModule", 
		"URL={p_URL}/web/index.php/time/viewTimeModule", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={p_URL}/web/index.php/dashboard/index", 
		"Snapshot=t65.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("messages_3", 
		"URL={p_URL}/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t66.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("clientBanner_2",
		"URL={p_URL}/web/index.php/admin/theme/image/clientBanner?v={v}",
		"Resource=0",
		"Referer={p_URL}/web/index.php/time/viewEmployeeTimesheet",
		"Snapshot=t67.inf",
		"Mode=HTTP",
		LAST);

	web_url("7_2", 
		"URL={p_URL}/web/index.php/pim/viewPhoto/empNumber/7", 
		"Resource=0", 
		"Referer={p_URL}/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t68.inf", 
		"Mode=HTTP", 
		LAST);


	web_url("list", 
		"URL={p_URL}/web/index.php/api/v2/time/employees/timesheets/list?limit=50&offset=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={p_URL}/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t69.inf", 
		"Mode=HTTP", 
		LAST);


	web_url("clientLogo_2",
		"URL={p_URL}/web/index.php/admin/theme/image/clientLogo?v={v}",
		"Resource=0",
		"Referer={p_URL}/web/index.php/time/viewEmployeeTimesheet",
		"Snapshot=t70.inf",
		"Mode=HTTP",
		LAST);

  if(atoi(lr_eval_string("TimeCount"))<0)

    {
     lr_end_transaction("HRM_Time_03_Click_Time",LR_FAIL); 
     lr_error_message("Click_Time failed");
    }
    else
    {
    lr_end_transaction("HRM_Time_03_Click_Time",LR_PASS);
     lr_output_message("Click_Time Page loaded Successfully");
    }

    
    web_reg_find ("Text=OrangeHRM","SaveCount=Click_ViewCount",LAST);

	lr_start_transaction("HRM_Time_04_Click_View");

	web_url("7_3",
		"URL={p_URL}/web/index.php/time/viewTimesheet/employeeId/7?startDate={p_Current_Date}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer={p_URL}/web/index.php/time/viewEmployeeTimesheet",
		"Snapshot=t71.inf",
		"Mode=HTTP",
		LAST);

	web_url("nunito-sans-v6-latin-ext_latin-300.woff2",
		"URL={p_URL}/web/dist/fonts/nunito-sans-v6-latin-ext_latin-300.woff2",
		"Resource=1",
		"Referer={p_URL}/web/dist/css/chunk-vendors.css?v={v}",
		"Snapshot=t72.inf",
		LAST);

	web_url("messages_4",
		"URL={p_URL}/web/index.php/core/i18n/messages",
		"Resource=0",
		"Referer={p_URL}/web/index.php/time/viewTimesheet/employeeId/7?startDate={p_Current_Date}",
		"Snapshot=t73.inf",
		"Mode=HTTP",
		LAST);

	web_url("orange.png",
		"URL={p_URL}/web/images/orange.png?v={v}",
		"Resource=1",
		"RecContentType=image/png",
		"Referer={p_URL}/web/index.php/time/viewTimesheet/employeeId/7?startDate={p_Current_Date}",
		"Snapshot=t74.inf",
		LAST);

	web_url("orangehrm-logo.png",
		"URL={p_URL}/web/images/orangehrm-logo.png?v={v}",
		"Resource=1",
		"RecContentType=image/png",
		"Referer={p_URL}/web/index.php/time/viewTimesheet/employeeId/7?startDate={p_Current_Date}",
		"Snapshot=t75.inf",
		LAST);

	web_url("7_4",
		"URL={p_URL}/web/index.php/pim/viewPhoto/empNumber/7",
		"Resource=0",
		"Referer={p_URL}/web/index.php/time/viewTimesheet/employeeId/7?startDate={p_Current_Date}",
		"Snapshot=t76.inf",
		"Mode=HTTP",
		LAST);

	web_url("default",
		"URL={p_URL}/web/index.php/api/v2/time/timesheets/default?date={p_Current_Date}&empNumber=7",
		"Resource=0",
		"RecContentType=application/json",
		"Referer={p_URL}/web/index.php/time/viewTimesheet/employeeId/7?startDate={p_Current_Date}",
		"Snapshot=t77.inf",
		"Mode=HTTP",
		LAST);

	
 if(atoi(lr_eval_string("Click_ViewCount"))<0)

    {
     lr_end_transaction("HRM_Time_04_Click_View",LR_FAIL); 
     lr_error_message("Click_View failed");
    }
    else
    {
    lr_end_transaction("HRM_Time_04_Click_View",LR_PASS);
     lr_output_message("Click_View Page loaded Successfully");
    }
	
	
	
	return 0;
}