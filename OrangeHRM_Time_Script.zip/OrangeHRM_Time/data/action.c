Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_sockets_option("TLS_SNI", "0");

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_auto_header("sec-ch-ua", 
		"\"Microsoft Edge\";v=\"125\", \"Chromium\";v=\"125\", \"Not.A/Brand\";v=\"24\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("opensource-demo.orangehrmlive.com", 
		"URL=https://opensource-demo.orangehrmlive.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t35.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"style");

	web_concurrent_start(NULL);

	web_url("chunk-vendors.css", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t36.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"style");

	web_url("app.css", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/css/app.css?v=1711595107870", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t37.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("chunk-vendors.js", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/js/chunk-vendors.js?v=1711595107870", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t38.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"script");

	web_url("app.js", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/js/app.js?v=1711595107870", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t39.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_url("favicon.ico", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/favicon.ico?v=1711595107870", 
		"Resource=1", 
		"RecContentType=image/vnd.microsoft.icon", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t40.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_set_sockets_option("TLS_SNI", "1");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("contentType", 
		"application/json");

	lr_think_time(25);

	web_url("messages", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t41.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_concurrent_start(NULL);

	web_url("ohrm_logo.png", 
		"URL=https://opensource-demo.orangehrmlive.com/web/images/ohrm_logo.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t42.inf", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Dest", 
		"font");

	web_url("bootstrap-icons.woff2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/fonts/bootstrap-icons.woff2", 
		"Resource=1", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Snapshot=t43.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_url("blob.svg", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/img/blob.svg", 
		"Resource=1", 
		"RecContentType=image/svg+xml", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/app.css?v=1711595107870", 
		"Snapshot=t44.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_url("loginBanner", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/admin/theme/image/loginBanner?v=1711595107870", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t45.inf", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Dest", 
		"font");

	web_url("nunito-sans-v6-latin-ext_latin-regular.woff2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/fonts/nunito-sans-v6-latin-ext_latin-regular.woff2", 
		"Resource=1", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Snapshot=t46.inf", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Dest", 
		"font");

	web_url("nunito-sans-v6-latin-ext_latin-800.woff2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/fonts/nunito-sans-v6-latin-ext_latin-800.woff2", 
		"Resource=1", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Snapshot=t47.inf", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Dest", 
		"font");

	web_url("nunito-sans-v6-latin-ext_latin-600.woff2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/fonts/nunito-sans-v6-latin-ext_latin-600.woff2", 
		"Resource=1", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Snapshot=t48.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(37);

	web_submit_data("validate", 
		"Action=https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/auth/login", 
		"Snapshot=t49.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=_token", "Value=4edc5a1c1a853.7ND2KFkuutbMsx5BPU0qhjW8ivxf2GjR6PBAMRuxLhM.gIeFfDFW97-cnioLa3Ri7W_u2rFuix6027R4d06HVySnvbpuP0LvpqTrfQ", ENDITEM, 
		"Name=username", "Value=Admin", ENDITEM, 
		"Name=password", "Value=admin123", ENDITEM, 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t50.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_concurrent_start(NULL);

	web_url("clientLogo", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/admin/theme/image/clientLogo?v=1711595107870", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t51.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_url("clientBanner", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/admin/theme/image/clientBanner?v=1711595107870", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t52.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_url("7", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPhoto/empNumber/7", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t53.inf", 
		LAST);

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"image");

	web_url("dashboard_empty_widget_watermark.png", 
		"URL=https://opensource-demo.orangehrmlive.com/web/images/dashboard_empty_widget_watermark.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t54.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("time-at-work", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/time-at-work?timezoneOffset=5.5&currentDate=2024-05-28&currentTime=16:29", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t55.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("shortcuts", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/shortcuts", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t56.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("action-summary", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/action-summary", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t57.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("feed", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/buzz/feed?limit=5&offset=0&sortOrder=DESC&sortField=share.createdAtUtc", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t58.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("subunit", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/subunit", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t59.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("leaves", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/leaves?date=2024-05-28", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t60.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_url("nunito-sans-v6-latin-ext_latin-italic.woff2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/fonts/nunito-sans-v6-latin-ext_latin-italic.woff2", 
		"Resource=1", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Snapshot=t61.inf", 
		LAST);

	web_url("locations", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/dashboard/employees/locations", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t62.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_url("nunito-sans-v6-latin-ext_latin-700.woff2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/fonts/nunito-sans-v6-latin-ext_latin-700.woff2", 
		"Resource=1", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Snapshot=t63.inf", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_custom_request("push", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/events/push", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t64.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_start_transaction("click_Time");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("viewTimeModule", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimeModule", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index", 
		"Snapshot=t65.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t66.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("clientBanner_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/admin/theme/image/clientBanner?v=1711595107870", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t67.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("7_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPhoto/empNumber/7", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t68.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_url("list", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/time/employees/timesheets/list?limit=50&offset=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t69.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("clientLogo_2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/admin/theme/image/clientLogo?v=1711595107870", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t70.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("click_Time",LR_AUTO);

	lr_start_transaction("click_View");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("7_3", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewEmployeeTimesheet", 
		"Snapshot=t71.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_header("Origin", 
		"https://opensource-demo.orangehrmlive.com");

	web_url("nunito-sans-v6-latin-ext_latin-300.woff2", 
		"URL=https://opensource-demo.orangehrmlive.com/web/dist/fonts/nunito-sans-v6-latin-ext_latin-300.woff2", 
		"Resource=1", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/dist/css/chunk-vendors.css?v=1711595107870", 
		"Snapshot=t72.inf", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("contentType", 
		"application/json");

	web_url("messages_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/core/i18n/messages", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Snapshot=t73.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("orange.png", 
		"URL=https://opensource-demo.orangehrmlive.com/web/images/orange.png?v=1711595107870", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Snapshot=t74.inf", 
		LAST);

	web_url("orangehrm-logo.png", 
		"URL=https://opensource-demo.orangehrmlive.com/web/images/orangehrm-logo.png?v=1711595107870", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Snapshot=t75.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"image");

	web_url("7_4", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewPhoto/empNumber/7", 
		"Resource=0", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Snapshot=t76.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_url("default", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/time/timesheets/default?date=2024-05-27&empNumber=7", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Snapshot=t77.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("holidays", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/holidays?fromDate=2024-01-01&toDate=2024-12-31", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Snapshot=t78.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("workweek", 
		"URL=https://opensource-demo.orangehrmlive.com/web/index.php/api/v2/leave/workweek?model=indexed", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://opensource-demo.orangehrmlive.com/web/index.php/time/viewTimesheet/employeeId/7?startDate=2024-05-27", 
		"Snapshot=t79.inf", 
		"Mode=HTTP", 
		LAST);

	return 0;
}